#ifndef	__TIMER_H
#define	__TIMER_H

#include "config.h"

void Timer0_Init(uchar ModeNum);

#endif
