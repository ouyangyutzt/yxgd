#ifndef	__DMX_H
#define	__DMX_H

#include "config.h"

void DMX_SigCRC(uint length);

#endif
