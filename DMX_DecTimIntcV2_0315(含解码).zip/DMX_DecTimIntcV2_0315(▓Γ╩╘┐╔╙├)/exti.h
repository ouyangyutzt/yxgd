#ifndef	__EXTI_H
#define	__EXTI_H

#include "config.h"

void Exti0Intc_Init(void);

#endif
