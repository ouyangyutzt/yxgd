#ifndef	__CONFIG_H
#define	__CONFIG_H

#include "STC15W104.h"
#include <intrins.h>
#include <stdio.h>

#define uint  unsigned int
#define uchar unsigned char

#endif
